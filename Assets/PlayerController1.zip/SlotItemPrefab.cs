using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SlotItemPrefab : MonoBehaviour
{

    public Image itemImage;
    public TextMeshProUGUI itemText;

    public  void ItemSetting(Sprite itemSprite, string txt)
    {
        itemImage.sprite = itemSprite;
        itemText.text = txt;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //public void UpdateInventory(Inventory myInven)
   //{
        //1. ���� ���� �ʱ�ȭ

        //2. �� �κ��丮 �����͸� ��ü Ž��
        //foreach (VertexGradient item in myInven.items)
        //{
        //    switch (item.Key)
        //    {
        //        case BlockType.Dirt:

        //            break;

        //        case BlockType.Grass:

        //            break;

        //        case BlockType.Water:

        //            break;

        //        case BlockType.Iron:

        //            break;
        //    }
        //}
    //}
}
